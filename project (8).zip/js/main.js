// main.js

$('video').mediaelementplayer({
  
});

// variables
const lines = document.getElementById("scriptWrap").getElementsByTagName("span");
const video = document.getElementsByTagName("video")[0];
const text = document.querySelector("#scriptWrap");

// highlight text as video plays
video.addEventListener("timeupdate", () => {
  for (var i = 0; i < lines.length; i++) {

    let start = lines[i].getAttribute("data-start");
    let end = lines[i].getAttribute("data-end");  
    let now = video.currentTime;

        if (now >= start && now < end) {
          lines[i].className = "highlight";
        } else { 
          lines[i].className = "";
        }
      }
});


// interactive transcript
text.addEventListener("click", (e) => {
  let currentTime = e.target.getAttribute("data-start");
  if (currentTime) {
    video.setCurrentTime(currentTime);
  }
});
